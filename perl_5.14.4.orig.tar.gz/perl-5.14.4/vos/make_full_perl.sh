# This macro makes full perl and runs its test scripts
gmake
gmake test
